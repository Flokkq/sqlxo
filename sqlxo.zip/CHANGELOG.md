# Changelog


## [0.2.1](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/compare/v0.2.0..v0.2.1) - 2025-11-01




### 🔧Chores

- *(release)* Prepare for v0.2.1 - ([957a16d](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/957a16d197bdea132182bdeccb03b90b91d5a475))


## [0.2.0](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/compare/v0.1.9..v0.2.0) - 2025-11-01




### 🔧Chores

- *(release)* Prepare for v0.2.0 - ([d6f80c3](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/d6f80c3a4f34cba969c8f779336f06cac63a684d))
- *(release)* Prepare for v0.1.9 - ([125fcec](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/125fcec80788a0a5f6e80e9b7010724825cc7ad8))


## [0.1.9](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/compare/v0.1.8..v0.1.9) - 2025-10-29




### 🔧Chores

- *(release)* Prepare for v0.1.9 - ([5c84326](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/5c843264a9da47e4a2db82ad862543fa01d90500))


## [0.1.8](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/compare/v0.1.7..v0.1.8) - 2025-10-29




### 🔧Chores

- *(release)* Prepare for v0.1.8 - ([35aa182](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/35aa1820c589b451e5805d3df8ba80732e3e80cc))


## [0.1.7](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/compare/v0.1.6..v0.1.7) - 2025-10-29




### 🔧Chores

- *(release)* Prepare for v0.1.7 - ([4769fe3](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/4769fe37ee112d886b6a867364ccdde1a1b0e49e))


## [0.1.6](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/compare/v0.1.5..v0.1.6) - 2025-10-29




### 🔧Chores

- *(release)* Prepare for v0.1.6 - ([532de8b](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/532de8b832674313482994952febe4d00ef98298))


## [0.1.5](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/compare/v0.1.4..v0.1.5) - 2025-10-29




### 🔧Chores

- *(release)* Prepare for v0.1.5 - ([28f9262](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/28f926297fffba836622b9dd401c391bd6f49d3d))


## [0.1.4](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/compare/v0.1.3..v0.1.4) - 2025-10-29




### 🔧Chores

- *(release)* Prepare for v0.1.4 - ([6c8e465](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/6c8e46527b337e34f6d313ee3d90d6cfef543ce1))


## [0.1.3](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/compare/v0.1.2..v0.1.3) - 2025-10-29




### 🔧Chores

- *(release)* Prepare for v0.1.3 - ([cde8e34](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/cde8e340c1e91db2665c3abad7641ee548fd7756))


## [0.1.2](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/compare/v0.1.1..v0.1.2) - 2025-10-29




### 🔧Chores

- *(release)* Prepare for v0.1.2 - ([c099621](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/c099621bc4177f0ec9a2fb08be07ee310ed1e4a6))


## [0.1.1](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/compare/v0.1.0..v0.1.1) - 2025-10-29




### 🔧Chores

- *(release)* Prepare for v0.1.1 - ([c943913](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/c94391368b84430671e4aaeb5425657c3932d755))


## [0.1.0] - 2025-10-29




### ✨ Features

- *(filter)* Convert api level struct to db filter enum - ([fe2d857](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/fe2d857bdbd48ce515418100b84196dcfe7aeb60))
- *(filter)* Generate dynamic sql queries given a filter enum vec - ([f9c8b4c](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/f9c8b4c3eee9b1b8a25149084dee76626c776b55))

### 🔧Chores

- *(release)* Prepare for v0.1.0 - ([1fb90f7](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/1fb90f773bbc9342a01bb426d2b4cc1a743d0c9c))
- *(repo)* Init - ([0cea957](https://github.com/Flokkq/https://gitlab.com/htbla-kaindorf/informatik-24/syp/syp-4bhif/lagermanagement/ci_cd_is_better_on_gh/commit/0cea957a006dafd44f3c05f95414cb8dbe01dac6))
<!-- generated by git-cliff -->
