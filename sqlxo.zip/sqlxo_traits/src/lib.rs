#![feature(trait_alias)]
#![forbid(unsafe_code)]

mod core;

pub use core::*;

mod web;

pub use web::*;

mod bind;

pub use bind::*;
