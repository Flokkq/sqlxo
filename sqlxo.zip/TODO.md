## final model

```sql
SELECT *
FROM item i
  JOIN user u ON i.user_id = u.user_id
  JOIN friend f ON u.friend_id = f.friend_id
WHERE 
(
  u.email LIKE "%example.com%" AND
  i.active = TRUE 
)
HAVING 
(
  AVG(i.price) > 100.0 AND
  COUNT(*) >= 3
)
ORDER BY 
  i.price DESC
  u.email ASC
```

```rust
use crate::query_engine::ctx_item_user_friend as ctx; // context!(Item, User, Friend)

const ITEM_TABLE = "item";

let q: BuiltQuery<ItemUserFriend> =
    QueryBuilder::from_ctx()
        .join(ctx::Join::ItemToUserByUserId(ctx::JoinKind::Inner))
        .join(ctx::Join::UserToFriendByFriendId(ctx::JoinKind::Left))
        .r#where(and![
            UserQuery::EmailLike("%@example.com".into()),
            ItemQuery::ActiveIsTrue,
        ])
        .having(and![
            Having::Item(ItemHaving::AvgPriceGt(100.0)),
            Having::CountGte(3),
        ])
        .order_by(SortOrder(vec![
            ctx::Sort::Item(ItemSort::ByPriceDesc),
            ctx::Sort::User(UserSort::ByEmailAsc),
        ]))
        .build();

let q: BuiltQuery<Item> = 
    QueryBuilder::from_ctx()
        .r#where(and![
            UserQuery::EmailLike("%@example.com".into()),
            ItemQuery::ActiveIsTrue,
        ])
        .build(&pool)
        .await?;
```


# Spec: Enum-Driven, Type-Safe Query System with sqlx Integration

This document is a complete prompt/spec for implementing a GraphQL/ORM-like dynamic querying system in Rust that is:

* **Enum-first and LSP-friendly** (users see only enums and simple builder methods).
* **Type-safe** for WHERE, GROUP BY, HAVING, ORDER BY, and JOINS.
* **Works with `sqlx::query_as`** (not the macros), returning **concrete types** inferred from the call site.
* **Auto-generated** from table definitions (derive macros + a `context!` macro).
* **Reusable** in backend and GraphQL layers.

The key idea: users write boolean trees with `Expression<T>` + `and!/or!` macros and pick **JOINs via raw enums**. A **generic `.build()`** method returns `Vec<T>` where `T` is inferred from `let rows: Vec<T> = ...build(...)?;` and is validated against the joins provided. No per-join methods, no visible generics, no projection picking by users.

---

## 0) User-Facing Goals and Constraints

* Users are not Rust experts: they should only see simple **enums** and a **builder** with obvious methods.
* Users write:

  * `and![]` / `or![]` boolean trees of **enum leaves** for WHERE/HAVING.
  * `join(ctx::Join::...)` with **raw join enums** (FKs pre-encoded).
  * `.build(&pool)` to fetch `Vec<T>` where `T` is inferred by the `let` binding type.
* System guarantees:

  * **Only valid operations appear** in auto-complete (thanks to generated enums).
  * **JOINs are restricted** to declared FKs.
  * **HAVING** allows only aggregates and grouped keys.
  * For **INNER** joins, output types contain **no `Option`**.
  * For **LEFT** joins, optionals appear **only** where you LEFT-joined.

---

## 1) Core Runtime Primitives

### 1.1 `Expression<T>` and boolean macros

```rust
#[derive(PartialEq, Debug, Clone)]
pub enum Expression<T> {
    And(Vec<Expression<T>>),
    Or(Vec<Expression<T>>),
    Leaf(T),
}

impl<T> From<T> for Expression<T> {
    fn from(t: T) -> Self { Expression::Leaf(t) }
}

#[macro_export]
macro_rules! and {
    ( $( $e:expr ),* $(,)? ) => {
        $crate::Expression::And(vec![ $( $crate::Expression::from($e) ),* ])
    };
}

#[macro_export]
macro_rules! or {
    ( $( $e:expr ),* $(,)? ) => {
        $crate::Expression::Or(vec![ $( $crate::Expression::from($e) ),* ])
    };
}
```

These remain the building blocks for WHERE and HAVING trees.

---

## 2) Schema Derives

Two derives drive codegen: `#[derive(Query)]` and `#[derive(Model)]`.

### 2.1 `#[derive(Query)]` (you already have this)

Given a public struct with named fields, it generates:

* `StructNameQuery` enum: WHERE-leaf variants per field, **type-correct** operators.
* `StructNameSort` enum: ORDER BY variants per field.
* `STRUCTNAME_TABLE: &str`: the SQL table name (from `#[filter(table_name = "...")]` or snake\_case default).

**Rules implemented (examples):**

* `String` → `Eq`, `Neq`, `Like`, `NotLike`, `IsNull`, `IsNotNull`
* `bool` → `IsTrue`, `IsFalse`
* numeric → `Eq`, `Neq`, `Gt`, `Gte`, `Lt`, `Lte`, `Between`, `NotBetween`
* `Uuid`/scalars → `Eq`, `Neq`, `IsNull`, `IsNotNull`
* `chrono::DateTime` → `On`, `Between`, `IsNull`, `IsNotNull`

### 2.2 `#[derive(Model)]`

Adds **relational and aggregation metadata** for the same struct:

* Table marker + column metadata (internal use for generation).
* **GroupKey enum**: columns legal in `GROUP BY` → `StructNameGroupKey`.
* **Having enum**: **aggregates as enums** per type (only valid combinations) → `StructNameHaving`.
* **FK declarations** via attribute: `#[model(table="item", pk=id, fks(user_id -> user.id))]`.

  * This is used to generate **Join enums** later.

**Having generation rules (examples):**

* numeric:

  * `Avg<Field>{Gt,Gte,Lt,Lte,Eq,Neq}(f64)`
  * `Sum<Field>{...}(widened-int/float)`
  * `Min<Field>{...}(T)`, `Max<Field>{...}(T)`
* datetime:

  * `Min<Field>{After,OnOrAfter,Before,OnOrBefore,Eq,Neq}(DateTime)`
  * `Max<Field>{...}(DateTime)`
* `CountRows{Gt,Gte,Eq,Neq,Lt,Lte}(u64)` per table
* strings: by default, no aggregates (can be gated by feature if you want `Min/Max` lexicographic).

---

## 3) Context Macro: `context!(A, B, C, ...)`

Users declare **which tables are in scope** for a query. This macro generates a module `ctx_a_b_c` with:

* `pub enum Where { A(AQuery), B(BQuery), ... }`
* `pub enum GroupKey { A(AGroupKey), B(BGroupKey), ... }`
* `pub enum Having { A(AHaving), B(BHaving), CountStarGt(u64), CountStarGte(u64), CountStarEq(u64), ... }`
* `pub enum Sort { A(ASort), B(BSort), ... }`
* `pub enum Join { ... }` — **all legal joins between the declared tables**, one variant **per FK** with a `JoinKind` payload.

Also emits a `Ctx` marker type (empty struct) to tag the builder.

### 3.1 `Join` generation

For each FK declared between any pair `(X,Y)` in the context, generate one variant:

```rust
pub enum JoinKind { Inner, Left /* keep it minimal */ }

pub enum Join {
    XToYBy<ForeignKeyName>(JoinKind), // e.g., ItemToUserByUserId(Inner)
    YToXBy<ForeignKeyName>(JoinKind)  // optionally both directions if you wish to allow either FROM side
}
```

The variant name encodes:

* Left table
* Right table
* The FK name (commonly the referencing column name)
* The exact **ON predicate** is **fixed and implied** by the variant (e.g., `item.user_id = user.id`).

No custom ON conditions from users.

---

## 4) Clause Enums (User-Facing Leaves)

* WHERE: `Expression<ctx_...::Where>` built out of `AQuery` / `BQuery` variants (thanks to `impl From`).
* GROUP BY: `Vec<ctx_...::GroupKey>`.
* HAVING: `Expression<ctx_...::Having>` built out of the generated `AHaving` / `BHaving` variants and `CountStar...`.
* ORDER BY: `SortOrder<Vec<ctx_...::Sort>>` that wraps per-table sort enums.

---

## 5) QueryBuilder

Single builder type parameterized by `CTX` (the context module).

```rust
pub struct QueryBuilder<CTX> {
    from: &'static str,
    joins: Vec<CTX::Join>,
    r#where: Option<Expression<CTX::Where>>,
    group_by: Vec<CTX::GroupKey>,
    having: Option<Expression<CTX::Having>>,
    order: Option<SortOrder<CTX::Sort>>,
    page: Option<Page>,
    _ctx: std::marker::PhantomData<CTX>,
}
```

Builder methods:

```rust
impl<CTX> QueryBuilder<CTX> {
    pub fn from(table: &'static str) -> Self { /* … */ }

    pub fn join(mut self, j: CTX::Join) -> Self {
        self.joins.push(j); self
    }

    pub fn r#where(mut self, e: Expression<CTX::Where>) -> Self { self.r#where = Some(e); self }

    pub fn group_by(mut self, keys: Vec<CTX::GroupKey>) -> Self { self.group_by = keys; self }

    pub fn having(mut self, e: Expression<CTX::Having>) -> Self { self.having = Some(e); self }

    pub fn order_by(mut self, s: SortOrder<CTX::Sort>) -> Self { self.order = Some(s); self }

    pub fn page(mut self, p: Page) -> Self { self.page = Some(p); self }

    /// Generic build; `T` is inferred from the LHS of the call site.
    pub async fn build<T>(self, pool: &sqlx::Pool<sqlx::Postgres>) -> Result<Vec<T>, sqlx::Error>
    where
        T: Projection<CTX>,
    {
        self.assert_required::<T>()?;
        let sql = self.to_sql_with_select(T::select_list());
        let rows: Vec<T::FlatRow> = sqlx::query_as(&sql).fetch_all(pool).await?;
        Ok(rows.into_iter().map(T::map).collect())
    }

    fn assert_required<T>(&self) -> Result<(), sqlx::Error>
    where
        T: Projection<CTX>,
    {
        // Compare self.joins (order-insensitive) with T::REQUIRED_JOINS.
        // Error on missing/extra/mismatched JoinKind, print a crisp diagnostic.
        Ok(())
    }

    fn to_sql_with_select(&self, select_list: &str) -> String {
        // Compose SELECT {select_list}
        // FROM self.from
        // + JOIN clauses from self.joins (each variant expands to a concrete ON)
        // + WHERE from Expression<CTX::Where>
        // + GROUP BY from Vec<CTX::GroupKey>
        // + HAVING from Expression<CTX::Having>
        // + ORDER BY from SortOrder<CTX::Sort>
        // + LIMIT/OFFSET from Page if present
        String::new()
    }
}
```

**Crucial point:** Users don’t write generics; `T` is inferred:

```rust
let v: Vec<Item>        = qb.build(&pool).await?;
let v: Vec<ItemUser>    = qb.build(&pool).await?;
let v: Vec<ItemOptUser> = qb.build(&pool).await?;
```

---

## 6) Projection Trait (Glue to `sqlx::query_as`)

One trait drives `build` for any return type:

```rust
pub trait Projection<CTX> {
    type FlatRow: for<'r> sqlx::FromRow<'r, sqlx::postgres::PgRow>;
    const REQUIRED_JOINS: &'static [CTX::Join];
    fn select_list() -> &'static str; // SQL `SELECT` list with aliases
    fn map(fr: Self::FlatRow) -> Self; // FlatRow -> Self (nested nice type)
}
```

### 6.1 Generated per **table**:

```rust
#[derive(Debug, Clone)]
pub struct Item { /* … */ }

#[derive(sqlx::FromRow)]
pub struct _Flat_Item { /* item_* with sqlx NOT NULL aliases "!" */ }

impl Projection<ctx_item_user::Ctx> for Item {
    type FlatRow = _Flat_Item;
    const REQUIRED_JOINS: &'static [ctx_item_user::Join] = &[];
    fn select_list() -> &'static str { SELECT_ITEM_ONLY }
    fn map(fr: _Flat_Item) -> Self { fr.into() }
}
```

### 6.2 Generated per **FK pair** (INNER and optionally LEFT):

```rust
#[derive(Debug, Clone)]
pub struct ItemUser { pub item: Item, pub user: User }

#[derive(sqlx::FromRow)]
pub struct _Flat_ItemUser { /* item_* ! + user_* ! */ }

impl Projection<ctx_item_user::Ctx> for ItemUser {
    type FlatRow = _Flat_ItemUser;
    const REQUIRED_JOINS: &'static [ctx_item_user::Join] =
        &[ ctx_item_user::Join::ItemToUserByUserId(ctx_item_user::JoinKind::Inner) ];
    fn select_list() -> &'static str { SELECT_ITEM_JOIN_USER_INNER }
    fn map(fr: _Flat_ItemUser) -> Self { fr.into() }
}

// Optional left-join variant:
#[derive(Debug, Clone)]
pub struct ItemOptUser { pub item: Item, pub user: Option<User> }

#[derive(sqlx::FromRow)]
pub struct _Flat_ItemOptUser { /* item_* ! + user_* nullable */ }

impl Projection<ctx_item_user::Ctx> for ItemOptUser {
    type FlatRow = _Flat_ItemOptUser;
    const REQUIRED_JOINS: &'static [ctx_item_user::Join] =
        &[ ctx_item_user::Join::ItemToUserByUserId(ctx_item_user::JoinKind::Left) ];
    fn select_list() -> &'static str { SELECT_ITEM_JOIN_USER_LEFT }
    fn map(fr: _Flat_ItemOptUser) -> Self { fr.into() }
}
```

> The number of Projection impls is: **#tables** + **#FKs** (×2 if you support both INNER and LEFT). This scales to large schemas without combinatorial explosion.

---

## 7) SELECT Alias Rules (for `sqlx::FromRow`)

* **Per table**, choose a stable prefix: `"item_"`, `"user_"`.
* Emit columns with `as "item_id!"`, `as "user_email!"` etc.

  * `!` indicates **NOT NULL** to `sqlx`.
  * For LEFT joins, **omit `!`** for the right side columns; the `_Flat_*` struct uses `Option<T>` for those.
* Column naming must match the fields in the `_Flat_*` structs exactly.

Example constants (generated once):

```rust
const SELECT_ITEM_ONLY: &str = r#"
  item.id          as "item_id!"
, item.name        as "item_name!"
, item.description as "item_description!"
, item.price       as "item_price!"
, item.amount      as "item_amount!"
, item.active      as "item_active!"
, item.due_date    as "item_due_date!"
, item.user_id     as "item_user_id!"
"#;

const SELECT_ITEM_JOIN_USER_INNER: &str = r#"
  item.id          as "item_id!"
, item.name        as "item_name!"
, item.description as "item_description!"
, item.price       as "item_price!"
, item.amount      as "item_amount!"
, item.active      as "item_active!"
, item.due_date    as "item_due_date!"
, item.user_id     as "item_user_id!"
, "user".id        as "user_id!"
, "user".email     as "user_email!"
"#;

const SELECT_ITEM_JOIN_USER_LEFT: &str = r#"
  item.id          as "item_id!"
, item.name        as "item_name!"
, item.description as "item_description!"
, item.price       as "item_price!"
, item.amount      as "item_amount!"
, item.active      as "item_active!"
, item.due_date    as "item_due_date!"
, item.user_id     as "item_user_id!"
, "user".id        as "user_id"
, "user".email     as "user_email"
"#;
```

---

## 8) JOIN SQL Emission

Each `ctx::Join` variant expands to a **fixed** SQL fragment:

```rust
match join_variant {
    Join::ItemToUserByUserId(JoinKind::Inner) => {
        r#" INNER JOIN "user" ON item.user_id = "user".id "#
    }
    Join::ItemToUserByUserId(JoinKind::Left) => {
        r#" LEFT JOIN "user" ON item.user_id = "user".id "#
    }
    // … generated for every FK in the context.
}
```

The builder’s `.to_sql_with_select` concatenates:
`SELECT … FROM {table} {joins} {WHERE} {GROUP BY} {HAVING} {ORDER BY} {LIMIT/OFFSET}`

---

## 9) HAVING and GROUP BY

* **GROUP BY**: `Vec<ctx::GroupKey>` where group keys are enums of columns per table.
* **HAVING**: `Expression<ctx::Having>`, where leaves are **aggregate comparisons** enums (e.g., `ItemHaving::AvgPriceGt(100.0)`), plus context-level `CountStar...` variants.
* Users use `and!/or!` to combine them (same as WHERE).

SQL generation rules:

* `GroupKey` → comma-separated column list (fully qualified).
* `Having` leaves render to function calls and comparisons (`AVG(item.price) > $1`, …), with parameters captured.

---

## 10) ORDER BY

Reuse existing `StructSort` enums per table. Context’s `Sort` wraps them:

* `Sort::Item(ItemSort::ByPriceDesc)`
* `Sort::User(UserSort::ByEmailAsc)`

SQL emission maps each variant to `ORDER BY item.price DESC`, etc.

---

## 11) Examples

### 11.1 Context with Item and User

```rust
#[derive(Debug, FromRow, Query, Model)]
#[filter(table_name = "item")]
#[model(table = "item", pk = id, fks(user_id -> user.id))]
pub struct Item { /* id, name, description, price, amount, active, due_date, user_id */ }

#[derive(Model, Query)]
#[model(table = "user", pk = id)]
#[filter(table_name = "user")]
pub struct User { /* id, email */ }

context!(Item, User); // emits module `ctx_item_user`
```

WHERE with boolean trees:

```rust
use crate::{and, or};
use crate::ctx_item_user;

let where_expr: Expression<ctx_item_user::Where> = and![
    UserQuery::EmailLike("%@example.com".into()),
    ItemQuery::ActiveIsTrue,
    or![
        and![
            ItemQuery::NameLike("%SternLampe%".into()),
            ItemQuery::DescriptionNotLike("%Hohlweg%".into()),
        ],
        ItemQuery::PriceGt(1800.0_f32),
    ],
];
```

GROUP BY and HAVING:

```rust
let group_keys = vec![
    ctx_item_user::GroupKey::User(UserGroupKey::Id),
    ctx_item_user::GroupKey::Item(ItemGroupKey::Active),
];

let having_expr: Expression<ctx_item_user::Having> = and![
    ctx_item_user::Having::Item(ItemHaving::AvgPriceGt(100.0_f64)),
    ctx_item_user::Having::CountStarGte(3_u64),
];
```

JOIN and build (INNER):

```rust
let item_user: Vec<ItemUser> =
    QueryBuilder::<ctx_item_user::Ctx>::from(ITEM_TABLE)
        .join(ctx_item_user::Join::ItemToUserByUserId(ctx_item_user::JoinKind::Inner))
        .r#where(where_expr.clone())
        .group_by(group_keys.clone())
        .having(having_expr.clone())
        .order_by(SortOrder(vec![
            ctx_item_user::Sort::Item(ItemSort::ByPriceDesc),
            ctx_item_user::Sort::User(UserSort::ByEmailAsc),
        ]))
        .build(&pool)
        .await?;
```

No JOIN and build base entity:

```rust
let item: Vec<Item> =
    QueryBuilder::<ctx_item_user::Ctx>::from(ITEM_TABLE)
        .r#where(where_expr)
        .build(&pool)
        .await?;
```

LEFT JOIN (optional relation):

```rust
let item_opt_user: Vec<ItemOptUser> =
    QueryBuilder::<ctx_item_user::Ctx>::from(ITEM_TABLE)
        .join(ctx_item_user::Join::ItemToUserByUserId(ctx_item_user::JoinKind::Left))
        .build(&pool)
        .await?;
```

Errors you should return during `build()`:

* **Missing join** for `T`: `"Projection ItemUser requires Join ItemToUserByUserId(Inner)"`.
* **Wrong JoinKind**: `"Projection ItemUser requires Inner but got Left"`.
* **Extra unsupported join**: `"Projection Item expects no joins but found: [ ... ]"`.

---

## 12) Codegen Plan (Macro Outputs)

For each public `struct` with `#[derive(Query, Model)]`:

1. Generate:

   * `StructQuery`, `StructSort`, `STRUCT_TABLE`.
   * `StructGroupKey`, `StructHaving`.
   * Column metadata (internal).

2. For each **context** `context!(A,B,...)`:

   * Module `ctx_a_b_...::` with:

     * `Ctx` marker.
     * `Where`, `GroupKey`, `Having`, `Sort` enums (wrapping per-table enums).
     * `JoinKind` and `Join` variants for every FK pair among the listed tables.
     * `impl From<AQuery> for Where` (and B, …).
     * `impl From<AGroupKey> for GroupKey` (and B, …).
     * `impl From<AHaving> for Having` (and B, …).
   * **Projection types** and implementations:

     * For each table X: `X` (nested), `_Flat_X` (sqlx row), `impl Projection<Ctx> for X`.
     * For each FK pair (X,Y): `X Y` and optionally `X OptY` with corresponding `_Flat_` and `impl Projection<Ctx> for ...`.
     * `SELECT_*` string constants with aliases.

3. (Optional later) For multi-hop common cases, generate `XY Z` shapes as needed; otherwise, users compose with GraphQL resolvers in multiple calls.

**Important:** Generate only what you have FKs for. Do **not** generate full cross products.

---

## 13) SQL Generation Details

* Keep **parameter binding** consistent; builder accumulates values for WHERE/HAVING.
* Use fully qualified column names in SELECT and ON: `"item".name`, `"user".email`.
* Ensure sqlx aliases exactly match `_Flat_*` field names; use `!` for NOT NULL on INNER-joined columns.
* ORDER BY uses qualified names (or positional ordinals) derived from Sort enums.

---

## 14) Testing Guidance

* Unit tests for `#[derive(Query)]` variants per type (like your existing tests).
* Derive tests for `GroupKey` and `Having` coverage by column type.
* Context tests:

  * JOIN variants exist only where FKs exist.
  * SELECT constants compile and alias correctly.
  * `Projection<Ctx>` impls build and map without panics.
* Integration tests with a test DB:

  * Base `Item` selection.
  * `ItemUser` inner join selection.
  * Left join `ItemOptUser` with null right rows.
  * Group/Having queries on aggregates (AVG, COUNT).

---

## 15) Performance and Binary Size

* Runtime cost is minimal:

  * One SQL string per query + `sqlx::FromRow` deserialization into a flat row + simple mapping.
* Binary size is controlled by the number of generated projections:

  * Generate per table and per FK pair (plus left variants if needed).
  * Unused code paths are dead-code-eliminated in release builds.
  * Use `lto = "thin"` and consider `codegen-units = 1` for maximal dedup.
* No reflection or dynamic dispatch in hot paths.

---

## 16) Minimal Implementation Checklist

1. Implement `Expression<T>`, `and!`, `or!`.
2. Implement `#[derive(Query)]` (you have this).
3. Implement `#[derive(Model)]`:

   * Parse `table`, `pk`, `fks(a -> b)` attributes.
   * Emit `GroupKey`, `Having` enums with type-correct variants.
4. Implement `context!(...)` macro:

   * Emit `Ctx`, `Where`, `GroupKey`, `Having`, `Sort`, `JoinKind`, `Join`.
   * `From` impls for WHERE/GROUP/HAVING wrappers.
5. Implement `Projection<CTX>` trait.
6. Auto-generate per-table and per-FK **Projection** impls:

   * Nested outputs (user-facing), `_Flat_*` sqlx rows (aliased), `SELECT_*` constants.
7. Implement `QueryBuilder<CTX>` with generic `build<T: Projection<CTX>>()`.
8. Implement SQL serialization from the builder and enums (SELECT/JOIN/WHERE/GROUP/HAVING/ORDER/PAGE).
9. Implement `assert_required::<T>()` join validation.
10. Write tests across types and contexts.

---

## 17) End-to-End Example (Final)

```rust
// Schema
#[derive(Debug, FromRow, Query, Model)]
#[filter(table_name = "item")]
#[model(table = "item", pk = id, fks(user_id -> user.id))]
pub struct Item { /* id, name, description, price, amount, active, due_date, user_id */ }

#[derive(Query, Model)]
#[filter(table_name = "user")]
#[model(table = "user", pk = id)]
pub struct User { /* id, email */ }

// Context
context!(Item, User);

use crate::{and, or};
use crate::ctx_item_user;

// WHERE tree
let w: Expression<ctx_item_user::Where> = and![
    UserQuery::EmailLike("%@example.com".into()),
    ItemQuery::ActiveIsTrue,
    or![ ItemQuery::NameLike("%Stern%".into()), ItemQuery::PriceGt(1800.0) ],
];

// GROUP + HAVING
let g = vec![
    ctx_item_user::GroupKey::User(UserGroupKey::Id),
    ctx_item_user::GroupKey::Item(ItemGroupKey::Active),
];

let h: Expression<ctx_item_user::Having> = and![
    ctx_item_user::Having::Item(ItemHaving::AvgPriceGt(100.0)),
    ctx_item_user::Having::CountStarGte(3),
];

// ORDER
let s = SortOrder(vec![
    ctx_item_user::Sort::Item(ItemSort::ByPriceDesc),
    ctx_item_user::Sort::User(UserSort::ByEmailAsc),
]);

// Inner join result (no Option)
let item_user: Vec<ItemUser> =
    QueryBuilder::<ctx_item_user::Ctx>::from(ITEM_TABLE)
        .join(ctx_item_user::Join::ItemToUserByUserId(ctx_item_user::JoinKind::Inner))
        .r#where(w.clone())
        .group_by(g.clone())
        .having(h.clone())
        .order_by(s.clone())
        .build(&pool)
        .await?;

// Base entity result (no joins)
let item: Vec<Item> =
    QueryBuilder::<ctx_item_user::Ctx>::from(ITEM_TABLE)
        .r#where(w)
        .build(&pool)
        .await?;
```

This is everything needed for another LLM—or a human—to implement the full system end to end: derives, enums, macros, builder, sqlx integration, aliasing, join validation, and examples.
